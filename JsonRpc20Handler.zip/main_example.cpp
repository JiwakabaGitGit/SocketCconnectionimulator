#include <cstdio>
#include "JsonRpc20Handler.hpp"

int main(void)
{
    JsonRpc20Handler handler;
    std::string      method;
    JsonRpc20Handler::RpcId id;

    // ── 正常リクエスト ────────────────────────────────────────────────────────
    const char* validJson =
        "{\"jsonrpc\":\"2.0\",\"method\":\"subtract\",\"params\":[42,23],\"id\":1}";

    int rc = handler.parseRequest(validJson, method, id);
    if (rc == JsonRpc20Handler::EC_OK) {
        printf("method : %s\n", method.c_str());
        printf("id type: %d  num: %lld\n",
               static_cast<int>(id.type),
               static_cast<long long>(id.num));

        // 成功レスポンス（result として数値 19 を返す例）
        yyjson_mut_doc* tmp_doc = yyjson_mut_doc_new(NULL);
        yyjson_mut_val* result  = yyjson_mut_int(tmp_doc, 19);

        // buildResponse は immutable val を受け取るため mut→write→read で変換
        char*       tmp_str  = yyjson_mut_val_write(result, 0, NULL);
        yyjson_doc* rdoc     = yyjson_read(tmp_str, strlen(tmp_str), 0);
        yyjson_val* rval     = rdoc ? yyjson_doc_get_root(rdoc) : NULL;

        std::string response = handler.buildResponse(id, rval);
        printf("response: %s\n\n", response.c_str());

        if (rdoc)    yyjson_doc_free(rdoc);
        if (tmp_str) free(tmp_str);
        yyjson_mut_doc_free(tmp_doc);
    }

    // ── Parse error ──────────────────────────────────────────────────────────
    {
        const char* broken = "{invalid json}";
        int ec = handler.parseRequest(broken, method, id);
        if (ec != JsonRpc20Handler::EC_OK) {
            JsonRpc20Handler::RpcId nullId;
            std::string errResp = handler.buildErrorResponse(
                nullId,
                static_cast<JsonRpc20Handler::ErrorCode>(ec));
            printf("error response: %s\n\n", errResp.c_str());
        }
    }

    // ── Invalid Request（method なし）────────────────────────────────────────
    {
        const char* noMethod = "{\"jsonrpc\":\"2.0\",\"id\":2}";
        int ec = handler.parseRequest(noMethod, method, id);
        if (ec != JsonRpc20Handler::EC_OK) {
            std::string errResp = handler.buildErrorResponse(
                id,
                static_cast<JsonRpc20Handler::ErrorCode>(ec));
            printf("error response: %s\n\n", errResp.c_str());
        }
    }

    return 0;
}
