#include "JsonRpc20Handler.hpp"
#include <cstring>
#include <cstdio>

// ─── helpers ──────────────────────────────────────────────────────────────────

static const char* const JSONRPC_VERSION = "2.0";

const char* JsonRpc20Handler::defaultMessage(ErrorCode code)
{
    switch (code) {
        case EC_PARSE_ERROR:      return "Parse error";
        case EC_INVALID_REQUEST:  return "Invalid Request";
        case EC_METHOD_NOT_FOUND: return "Method not found";
        case EC_INVALID_PARAMS:   return "Invalid params";
        case EC_INTERNAL_ERROR:   return "Internal error";
        default:                  return "Server error";
    }
}

// Append "id": <value> to a mutable JSON object
void JsonRpc20Handler::appendIdToObj(yyjson_mut_doc* doc,
                                     yyjson_mut_val* obj,
                                     const RpcId&    id)
{
    yyjson_mut_val* key = yyjson_mut_str(doc, "id");
    yyjson_mut_val* val = NULL;

    switch (id.type) {
        case RpcId::ID_STRING:
            val = yyjson_mut_str(doc, id.str.c_str());
            break;
        case RpcId::ID_NUMBER:
            val = yyjson_mut_int(doc, id.num);
            break;
        default:   // ID_NULL
            val = yyjson_mut_null(doc);
            break;
    }

    yyjson_mut_obj_add(obj, key, val);
}

// ─── constructor / destructor ─────────────────────────────────────────────────

JsonRpc20Handler::JsonRpc20Handler()  {}
JsonRpc20Handler::~JsonRpc20Handler() {}

// ─── parseRequest ─────────────────────────────────────────────────────────────

int JsonRpc20Handler::parseRequest(const char*  json,
                                    std::string& method,
                                    RpcId&       id)
{
    if (!json || json[0] == '\0') {
        return EC_PARSE_ERROR;
    }

    yyjson_read_err  err;
    yyjson_doc*      doc = yyjson_read_opts(
        const_cast<char*>(json),
        std::strlen(json),
        YYJSON_READ_NOFLAG,
        NULL,
        &err);

    if (!doc) {
        return EC_PARSE_ERROR;
    }

    int result = EC_OK;

    yyjson_val* root = yyjson_doc_get_root(doc);
    if (!root || !yyjson_is_obj(root)) {
        result = EC_INVALID_REQUEST;
        goto cleanup;
    }

    // ── "jsonrpc" must equal "2.0" ───────────────────────────────────────────
    {
        yyjson_val* ver = yyjson_obj_get(root, "jsonrpc");
        if (!ver || !yyjson_is_str(ver) ||
            std::strcmp(yyjson_get_str(ver), JSONRPC_VERSION) != 0) {
            result = EC_INVALID_REQUEST;
            goto cleanup;
        }
    }

    // ── "method" must be a non-empty string ──────────────────────────────────
    {
        yyjson_val* mval = yyjson_obj_get(root, "method");
        if (!mval || !yyjson_is_str(mval)) {
            result = EC_INVALID_REQUEST;
            goto cleanup;
        }
        const char* mstr = yyjson_get_str(mval);
        if (!mstr || mstr[0] == '\0') {
            result = EC_INVALID_REQUEST;
            goto cleanup;
        }
        method = mstr;
    }

    // ── "id": string | number | null (omitted → notification, treat as null) ─
    {
        yyjson_val* idval = yyjson_obj_get(root, "id");
        id = RpcId(); // default: null

        if (idval) {
            if (yyjson_is_str(idval)) {
                id.type = RpcId::ID_STRING;
                id.str  = yyjson_get_str(idval);
            } else if (yyjson_is_int(idval)) {
                id.type = RpcId::ID_NUMBER;
                id.num  = yyjson_get_sint(idval);
            } else if (yyjson_is_null(idval)) {
                id.type = RpcId::ID_NULL;
            } else {
                // id is present but neither string / integer / null → invalid
                result = EC_INVALID_REQUEST;
                goto cleanup;
            }
        }
    }

cleanup:
    yyjson_doc_free(doc);
    return result;
}

// ─── buildResponse ────────────────────────────────────────────────────────────

std::string JsonRpc20Handler::buildResponse(const RpcId& id,
                                             yyjson_val*  result)
{
    yyjson_mut_doc* doc = yyjson_mut_doc_new(NULL);
    yyjson_mut_val* obj = yyjson_mut_obj(doc);
    yyjson_mut_doc_set_root(doc, obj);

    yyjson_mut_obj_add_str(doc, obj, "jsonrpc", JSONRPC_VERSION);

    // Copy immutable result value into mutable doc
    yyjson_mut_val* mresult = yyjson_val_mut_copy(doc, result);
    if (!mresult) {
        mresult = yyjson_mut_null(doc);
    }
    yyjson_mut_obj_add(obj, yyjson_mut_str(doc, "result"), mresult);

    appendIdToObj(doc, obj, id);

    char*       json_str = yyjson_mut_write(doc, YYJSON_WRITE_NOFLAG, NULL);
    std::string output   = json_str ? json_str : "";
    if (json_str) {
        free(json_str);
    }

    yyjson_mut_doc_free(doc);
    return output;
}

// ─── buildErrorResponse ───────────────────────────────────────────────────────

std::string JsonRpc20Handler::buildErrorResponse(const RpcId& id,
                                                  ErrorCode    code,
                                                  const char*  message)
{
    const char* msg = (message && message[0] != '\0')
                      ? message
                      : defaultMessage(code);

    yyjson_mut_doc* doc = yyjson_mut_doc_new(NULL);
    yyjson_mut_val* obj = yyjson_mut_obj(doc);
    yyjson_mut_doc_set_root(doc, obj);

    yyjson_mut_obj_add_str(doc, obj, "jsonrpc", JSONRPC_VERSION);

    // "error": { "code": <int>, "message": <str> }
    yyjson_mut_val* err_obj = yyjson_mut_obj(doc);
    yyjson_mut_obj_add_int(doc, err_obj, "code",    static_cast<int64_t>(code));
    yyjson_mut_obj_add_str(doc, err_obj, "message", msg);
    yyjson_mut_obj_add(obj, yyjson_mut_str(doc, "error"), err_obj);

    appendIdToObj(doc, obj, id);

    char*       json_str = yyjson_mut_write(doc, YYJSON_WRITE_NOFLAG, NULL);
    std::string output   = json_str ? json_str : "";
    if (json_str) {
        free(json_str);
    }

    yyjson_mut_doc_free(doc);
    return output;
}
