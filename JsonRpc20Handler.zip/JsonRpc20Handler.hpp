#ifndef JSONRPC20_HANDLER_HPP
#define JSONRPC20_HANDLER_HPP

#include <string>
#include <stdint.h>
#include "yyjson.h"

// JSON RPC 2.0 handler using yyjson
// Targets QNX 6 (Neutrino), compiled with GCC in C++03/C++11 mode.
class JsonRpc20Handler {
public:
    // Standard JSON RPC 2.0 error codes
    enum ErrorCode {
        EC_OK               =  0,
        EC_PARSE_ERROR      = -32700,  // Invalid JSON
        EC_INVALID_REQUEST  = -32600,  // Not a valid Request object
        EC_METHOD_NOT_FOUND = -32601,  // Method does not exist
        EC_INVALID_PARAMS   = -32602,  // Invalid method parameters
        EC_INTERNAL_ERROR   = -32603   // Internal JSON RPC error
    };

    // Representation of the "id" field (string | number | null)
    struct RpcId {
        enum Type { ID_NULL, ID_STRING, ID_NUMBER } type;
        std::string str;   // valid when type == ID_STRING
        int64_t     num;   // valid when type == ID_NUMBER

        RpcId() : type(ID_NULL), num(0) {}
    };

    JsonRpc20Handler();
    ~JsonRpc20Handler();

    // Parse a JSON RPC 2.0 request message.
    // On success  : returns EC_OK, writes method and id.
    // On failure  : returns a negative ErrorCode; method and id are undefined.
    //
    // Parameters
    //   json   - raw JSON string (null-terminated)
    //   method - [out] method name from the request
    //   id     - [out] id field from the request
    int parseRequest(const char* json, std::string& method, RpcId& id);

    // Build a success response JSON string.
    // result must be a yyjson value owned by the caller; it is read but not freed here.
    std::string buildResponse(const RpcId& id, yyjson_val* result);

    // Build an error response JSON string.
    // If message is NULL the standard message for the code is used.
    std::string buildErrorResponse(const RpcId& id, ErrorCode code,
                                   const char* message = NULL);

private:
    static const char* defaultMessage(ErrorCode code);
    static void        appendIdToObj(yyjson_mut_doc* doc,
                                     yyjson_mut_val* obj,
                                     const RpcId&    id);
};

#endif // JSONRPC20_HANDLER_HPP
