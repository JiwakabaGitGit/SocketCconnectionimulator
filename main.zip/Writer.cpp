/**
 * @file  Writer.cpp
 * @brief Writer クラスの実装
 *
 * 動作環境: QNX 7
 *
 * NOTE: 現在は標準出力へのダミー書き込みを行っている。
 *       実際の書き込み先（ファイル、デバイス、共有メモリ等）に合わせて
 *       write() メソッドの実装を変更すること。
 */

#include "Writer.h"

#include <iostream>
#include <stdexcept>

/* ------------------------------------------------------------------ */
/* コンストラクタ / デストラクタ                                        */
/* ------------------------------------------------------------------ */

Writer::Writer(const std::string& destination)
    : m_destination(destination)
{
    // 必要であれば、ここでリソース（ファイル、デバイス等）をオープンする
}

Writer::~Writer()
{
    // 必要であれば、ここでリソースをクローズする
}

/* ------------------------------------------------------------------ */
/* 公開メソッド                                                         */
/* ------------------------------------------------------------------ */

bool Writer::write(const std::string& data)
{
    // ---------------------------------------------------------------
    // TODO: ここに実際の書き込み処理を実装する
    //
    // 例1) ファイルへの書き込み:
    //   std::ofstream ofs(m_destination, std::ios::app);
    //   if (!ofs) return false;
    //   ofs << data << std::endl;
    //
    // 例2) デバイス / シリアルポートへの書き込み (QNX POSIX API):
    //   int fd = open(m_destination.c_str(), O_WRONLY);
    //   if (fd == -1) return false;
    //   ssize_t written = ::write(fd, data.c_str(), data.size());
    //   close(fd);
    //   return (written == static_cast<ssize_t>(data.size()));
    // ---------------------------------------------------------------

    // --- ダミー実装（標準出力に書き込む）---
    std::cout << "[Writer] 書き込み先=\"" << m_destination << "\""
              << " データ=\"" << data << "\"" << std::endl;

    return true;
}

void Writer::setDestination(const std::string& destination)
{
    m_destination = destination;
}

std::string Writer::getDestination() const
{
    return m_destination;
}
