/**
 * @file  Writer.h
 * @brief 書き込み処理を担う Writer クラスの宣言
 *
 * 動作環境: QNX 7
 */

#ifndef WRITER_H
#define WRITER_H

#include <string>

/**
 * @class Writer
 * @brief データの書き込みを行う独自クラス
 *
 * 書き込み先や書き込み方法はこのクラス内に集約する。
 * 必要に応じてコンストラクタの引数や write() のオーバーロードを追加すること。
 */
class Writer
{
public:
    /**
     * @brief コンストラクタ
     * @param destination 書き込み先の識別子（ファイルパス、デバイス名など）
     */
    explicit Writer(const std::string& destination = "");

    /**
     * @brief デストラクタ
     */
    ~Writer();

    /**
     * @brief 書き込みを実行する
     * @param data 書き込むデータ（文字列）
     * @return true  書き込み成功
     * @return false 書き込み失敗
     */
    bool write(const std::string& data);

    /**
     * @brief 書き込み先を設定する
     * @param destination 書き込み先の識別子
     */
    void setDestination(const std::string& destination);

    /**
     * @brief 現在の書き込み先を取得する
     * @return 書き込み先の識別子
     */
    std::string getDestination() const;

private:
    std::string m_destination; ///< 書き込み先の識別子
};

#endif // WRITER_H
