/**
 * @file  main.cpp
 * @brief QNX コンソールツール エントリーポイント
 *
 * 動作環境: QNX 7
 *
 * 【概要】
 *   標準入力からコマンドを対話式に受け付け、対応する処理を実行する。
 *
 * 【コマンド一覧】
 *   write <データ>  - Writer クラスの write() を呼び出してデータを書き込む
 *   exit            - アプリを正常終了する
 *   quit            - exit の別名
 *   help            - コマンド一覧を表示する
 *
 * 【ビルド (QNX 7)】
 *   make
 *
 * 【使用例】
 *   $ ./qnx_console_tool
 *   > write Hello, QNX!
 *   [Writer] 書き込み先="" データ="Hello, QNX!"
 *   > exit
 *   アプリを終了します。
 */

#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
#include <cstdlib>

#include "Writer.h"

/* ------------------------------------------------------------------ */
/* 定数                                                                 */
/* ------------------------------------------------------------------ */

static const char* PROMPT        = "> ";
static const char* APP_NAME      = "QNX コンソールツール";
static const char* APP_VERSION   = "1.0.0";

/* ------------------------------------------------------------------ */
/* ユーティリティ関数                                                   */
/* ------------------------------------------------------------------ */

/**
 * @brief 文字列を先頭・末尾の空白を取り除いて返す
 */
static std::string trim(const std::string& s)
{
    const std::string whitespace = " \t\r\n";
    std::size_t start = s.find_first_not_of(whitespace);
    if (start == std::string::npos) return "";
    std::size_t end = s.find_last_not_of(whitespace);
    return s.substr(start, end - start + 1);
}

/**
 * @brief 文字列を空白で分割し、先頭トークンとそれ以降の文字列を返す
 * @param[in]  line    入力文字列
 * @param[out] cmd     先頭のコマンドトークン（小文字化済み）
 * @param[out] args    コマンド以降の引数文字列（先頭空白除去済み）
 */
static void parseCommand(const std::string& line,
                         std::string&       cmd,
                         std::string&       args)
{
    std::istringstream iss(line);
    iss >> cmd;

    // 小文字化（大文字小文字を区別しない）
    std::transform(cmd.begin(), cmd.end(), cmd.begin(), ::tolower);

    // コマンド部分の長さ分を読み飛ばして残りを args へ
    std::size_t pos = line.find(cmd);
    if (pos != std::string::npos)
    {
        pos += cmd.size();
        args = (pos < line.size()) ? trim(line.substr(pos)) : "";
    }
    else
    {
        args = "";
    }
}

/* ------------------------------------------------------------------ */
/* コマンドハンドラ                                                     */
/* ------------------------------------------------------------------ */

/**
 * @brief ヘルプを表示する
 */
static void cmdHelp()
{
    std::cout << "\n"
              << "  コマンド一覧:\n"
              << "  -----------------------------------------------\n"
              << "  write <データ>  書き込み処理を実行する\n"
              << "  exit            アプリを終了する\n"
              << "  quit            exit の別名\n"
              << "  help            このヘルプを表示する\n"
              << "  -----------------------------------------------\n"
              << std::endl;
}

/**
 * @brief write コマンドを処理する
 * @param writer Writer インスタンス
 * @param args   書き込むデータ文字列
 */
static void cmdWrite(Writer& writer, const std::string& args)
{
    if (args.empty())
    {
        std::cerr << "[エラー] 書き込むデータを指定してください。"
                  << "  使用例: write <データ>" << std::endl;
        return;
    }

    bool ok = writer.write(args);
    if (!ok)
    {
        std::cerr << "[エラー] 書き込みに失敗しました。" << std::endl;
    }
    else
    {
        std::cout << "[OK] 書き込みが完了しました。" << std::endl;
    }
}

/* ------------------------------------------------------------------ */
/* メインループ                                                         */
/* ------------------------------------------------------------------ */

/**
 * @brief 対話式コマンドループを実行する
 * @param writer Writer インスタンス
 * @return 終了コード (0: 正常, 1: エラー)
 */
static int runCommandLoop(Writer& writer)
{
    std::string line;

    std::cout << "\n"
              << APP_NAME << " v" << APP_VERSION << "\n"
              << "コマンドを入力してください。"
              << " (\"help\" でコマンド一覧を表示)\n"
              << std::endl;

    while (true)
    {
        std::cout << PROMPT;
        std::cout.flush();

        if (!std::getline(std::cin, line))
        {
            // EOF (Ctrl+D) を受け取った場合は正常終了
            std::cout << "\nアプリを終了します。" << std::endl;
            break;
        }

        line = trim(line);
        if (line.empty()) continue;

        std::string cmd;
        std::string args;
        parseCommand(line, cmd, args);

        /* ----- コマンド分岐 ----- */
        if (cmd == "write")
        {
            cmdWrite(writer, args);
        }
        else if (cmd == "exit" || cmd == "quit")
        {
            std::cout << "アプリを終了します。" << std::endl;
            break;
        }
        else if (cmd == "help" || cmd == "?")
        {
            cmdHelp();
        }
        else
        {
            std::cerr << "[エラー] 不明なコマンド: \"" << cmd << "\""
                      << "  (\"help\" でコマンド一覧を表示)" << std::endl;
        }
    }

    return EXIT_SUCCESS;
}

/* ------------------------------------------------------------------ */
/* エントリーポイント                                                   */
/* ------------------------------------------------------------------ */

int main(int argc, char* argv[])
{
    // 書き込み先を起動引数で指定可能にする（省略時は空文字列）
    std::string destination = "";
    if (argc >= 2)
    {
        destination = argv[1];
    }

    // Writer インスタンスを生成
    Writer writer(destination);

    // 対話式コマンドループを実行
    return runCommandLoop(writer);
}
